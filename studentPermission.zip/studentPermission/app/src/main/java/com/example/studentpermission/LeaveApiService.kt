package com.example.studentpermission

import com.example.studentpermission.ui.models.LeaveRequest
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface LeaveApiService {
    @POST("api/leave/submit")
    fun submitLeaveRequest(@Body request: LeaveRequest): Call<List<LeaveRequest>>

    @GET("api/leavehistory/leave-history")
    fun getLeaveHistory(@Query("email") email: String): Call<List<LeaveRequest>>

    @GET("api/users/faculty/requests") // Updated endpoint URL
    fun getRequestsForFaculty(@Query("facultyName") facultyName: String): Call<List<LeaveRequest>>
}