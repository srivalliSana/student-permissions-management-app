package com.example.studentpermission.ui.screens

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.R
import com.example.studentpermission.ui.adapters.LeaveApprovalAdapter
import com.example.studentpermission.ui.models.LeaveRequest

class LeaveApprovalActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var leaveAdapter: LeaveApprovalAdapter
    private val leaveRequests = mutableListOf<LeaveRequest>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leave_approval)

        recyclerView = findViewById(R.id.rvLeaveRequests)
        recyclerView.layoutManager = LinearLayoutManager(this)

        leaveAdapter = LeaveApprovalAdapter(leaveRequests, ::approveLeave, ::rejectLeave)
        recyclerView.adapter = leaveAdapter

        fetchLeaveRequests()
    }

    private fun fetchLeaveRequests() {
        val sharedPreferences: SharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val facultyRole = sharedPreferences.getString("facultyRole", "HOD") // Default: HOD
        val facultyEmail = sharedPreferences.getString("facultyEmail", "") // Get the faculty email

        leaveRequests.clear()

        // Placeholder data for testing (replace with actual data fetching logic)
        val testRequests = listOf(
            LeaveRequest(
                studentEmail = "john.doe@cutmap.ac.in",
                leaveType = "Medical Leave",
                startDate = "2024-03-20",
                otherLeaveType = "",
                endDate = "2024-03-21",
                startTime = "08:00 AM",
                endTime = "05:00 PM",
                leaveDate = "2024-03-20",
                reason = "Fever",
                status = "Pending",
                mentorApprover = "Evelyn Garcia", // Example mentor name
                hodApprover = "Oliver Brown", // Example HOD name
                registrarApprover = "Henry Wilson", // Example registrar name
                chiefWardenApprover = "Zoe Martinez",
                superintendentApprover = "Chloe Taylor"
            ),
            LeaveRequest(
                studentEmail = "jane.smith@cutmap.ac.in",
                leaveType = "Outing",
                startDate = "2024-03-25",
                otherLeaveType = "",
                endDate = "",
                startTime = "09:00 AM",
                endTime = "06:00 PM",
                leaveDate = "2024-03-25",
                reason = "Personal work",
                status = "Pending",
                mentorApprover = "Elijah White",
                hodApprover = "Scarlett Harris",
                registrarApprover = "Lily Jackson",
                chiefWardenApprover = "Zoe Martinez",
                superintendentApprover = "Chloe Taylor"
            )
        )

        testRequests.forEach { request ->
            when (facultyRole) {
                "Mentor" -> {
                    if (request.mentorApprover == facultyEmail) {
                        leaveRequests.add(request)
                    }
                }
                "HOD" -> {
                    if (request.hodApprover == facultyEmail) {
                        leaveRequests.add(request)
                    }
                }
                "Chief Warden" -> {
                    if (request.chiefWardenApprover == facultyEmail) {
                        leaveRequests.add(request)
                    }
                }
                "Hostel Superintendent" -> {
                    if (request.superintendentApprover == facultyEmail) {
                        leaveRequests.add(request)
                    }
                }
                "Deputy Registrar" -> {
                    leaveRequests.add(request) // Deputy Registrar sees all
                }
            }
        }

        leaveAdapter.notifyDataSetChanged()
    }

    private fun approveLeave(request: LeaveRequest) {
        val sharedPreferences: SharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val facultyRole = sharedPreferences.getString("facultyRole", "HOD") // Default: HOD

        val updatedRequest = request.copy(status = "Approved by $facultyRole")

        // Logic to update the request in your data source (e.g., database)
        // ... (Use updatedRequest here)

        val nextApprover = when (facultyRole) {
            "Mentor" -> updatedRequest.hodApprover
            "HOD" -> if (updatedRequest.chiefWardenApprover != null) updatedRequest.chiefWardenApprover else updatedRequest.registrarApprover
            "Chief Warden" -> updatedRequest.superintendentApprover
            "Hostel Superintendent" -> updatedRequest.registrarApprover
            else -> null // For Deputy Registrar, no next approver
        }

        if (nextApprover != null) {
            Toast.makeText(this, "Leave Approved. Forwarding to $nextApprover", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Leave Approved. Final approval", Toast.LENGTH_SHORT).show()
        }

        fetchLeaveRequests() // Refresh the list
    }

    private fun rejectLeave(request: LeaveRequest) {
        val updatedRequest = request.copy(status = "Rejected")

        // Logic to update the request in your data source
        // ... (Use updatedRequest here)

        Toast.makeText(this, "Leave Rejected: ${request.studentEmail}", Toast.LENGTH_SHORT).show()
        fetchLeaveRequests() // Refresh the list
    }
}