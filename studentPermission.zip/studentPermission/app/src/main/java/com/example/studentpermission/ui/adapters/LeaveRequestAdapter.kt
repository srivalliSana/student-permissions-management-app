package com.example.studentpermission.ui.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.R
import com.example.studentpermission.ui.models.LeaveRequest

class LeaveRequestAdapter(private val leaveRequests: List<LeaveRequest>) :
    RecyclerView.Adapter<LeaveRequestAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val studentEmail: TextView = view.findViewById(R.id.tvStudentEmail)
        val leaveDate: TextView = view.findViewById(R.id.tvLeaveDate)
        val leaveType: TextView = view.findViewById(R.id.tvLeaveType)
        val status: TextView = view.findViewById(R.id.tvStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_leave_request, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val request = leaveRequests[position]

        Log.d("LeaveRequestAdapter", "Binding request at position $position: $request")
        Log.d("LeaveRequestAdapter", "studentEmail: ${request.studentEmail}")
        Log.d("LeaveRequestAdapter", "leaveDate: ${request.leaveDate}")
        Log.d("LeaveRequestAdapter", "leaveType: ${request.leaveType}")
        Log.d("LeaveRequestAdapter", "status: ${request.status}")

        holder.studentEmail.text = request.studentEmail ?: "N/A"
        holder.leaveDate.text = request.leaveDate ?: "N/A"
        holder.leaveType.text = request.leaveType ?: "N/A"
        holder.status.text = request.status ?: "N/A"
    }

    override fun getItemCount(): Int = leaveRequests.size
}