package com.example.studentpermission.ui

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studentpermission.R
import com.example.studentpermission.ui.models.LeaveRequest

class LeaveDetailActivity : AppCompatActivity() {

    private lateinit var tvLeaveType: TextView
    private lateinit var tvStartDate: TextView
    private lateinit var tvEndDate: TextView
    private lateinit var tvStartTime: TextView
    private lateinit var tvEndTime: TextView
    private lateinit var tvReason: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvLeaveDate: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leave_detail)

        // Initialize views
        tvLeaveType = findViewById(R.id.tvLeaveType)
        tvStartDate = findViewById(R.id.tvStartDate)
        tvEndDate = findViewById(R.id.tvEndDate)
        tvStartTime = findViewById(R.id.tvStartTime)
        tvEndTime = findViewById(R.id.tvEndTime)
        tvReason = findViewById(R.id.tvReason)
        tvStatus = findViewById(R.id.tvStatus)
        tvLeaveDate = findViewById(R.id.tvLeaveDate)

        // Get LeaveRequest data from Intent
        val leaveRequest = intent.getSerializableExtra("leaveRequest") as? LeaveRequest

        if (leaveRequest != null) {
            displayLeaveDetails(leaveRequest)
        } else {
            Toast.makeText(this, "Error: No leave data found", Toast.LENGTH_SHORT).show()
            finish() // Close activity if no data
        }
    }

    private fun displayLeaveDetails(leaveRequest: LeaveRequest) {
        tvLeaveType.text = leaveRequest.leaveType
        tvStartDate.text = leaveRequest.startDate
        tvEndDate.text = leaveRequest.endDate
        tvStartTime.text = leaveRequest.startTime
        tvEndTime.text = leaveRequest.endTime
        tvReason.text = leaveRequest.reason
        tvStatus.text = leaveRequest.status
        tvLeaveDate.text = leaveRequest.leaveDate
    }
}
