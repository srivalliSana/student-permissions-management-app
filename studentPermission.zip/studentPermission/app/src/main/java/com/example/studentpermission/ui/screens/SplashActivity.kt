package com.example.studentpermission.ui.screens

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.studentpermission.R
import com.example.studentpermission.ui.screens.LoginActivity
import com.example.studentpermission.ui.screens.HomeActivity
import com.example.studentpermission.SessionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val sessionManager = SessionManager(this)

        lifecycleScope.launch {
            delay(2000) // 2 seconds delay

            val nextActivity = if (sessionManager.isLoggedIn()) {
                HomeActivity::class.java // If user is logged in, go to main screen
            } else {
                LoginActivity::class.java // Otherwise, go to login screen
            }

            startActivity(Intent(this@SplashActivity, nextActivity))
            finish() // Close Splash Screen
        }
    }
}
