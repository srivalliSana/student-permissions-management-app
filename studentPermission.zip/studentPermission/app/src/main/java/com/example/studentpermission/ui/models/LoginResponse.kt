package com.example.studentpermission.ui.models

data class LoginResponse(val message: String, val role: String,val name: String?)