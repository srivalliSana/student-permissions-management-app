package com.example.studentpermission.ui.screens

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studentpermission.R
import com.example.studentpermission.RetrofitClient
import com.example.studentpermission.ui.models.LoginRequest
import com.example.studentpermission.ui.models.LoginResponse
import com.google.android.gms.auth.api.signin.*
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient
    private val RC_SIGN_IN = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnForgotPassword = findViewById<Button>(R.id.btnForgotPassword)
        val btnGoogleSignIn = findViewById<Button>(R.id.btnGoogleSignIn)

        val googleApiAvailability = GoogleApiAvailability.getInstance()
        val status = googleApiAvailability.isGooglePlayServicesAvailable(this)
        if (status != ConnectionResult.SUCCESS) {
            googleApiAvailability.getErrorDialog(this, status, 9000)?.show()
        }

        // Use Web Client ID (ensure this is correct)
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("YOUR_WEB_CLIENT_ID") // Make sure this matches your credentials
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        btnLogin.setOnClickListener {
            val email = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (!isValidEmail(email)) {
                showToast("Enter a valid email")
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                showToast("Please enter a password")
                return@setOnClickListener
            }

            loginUser(email, password)
        }

        btnForgotPassword.setOnClickListener {
            startActivity(Intent(this, ForgotPasswordActivity::class.java))
        }

        btnGoogleSignIn.setOnClickListener {
            signOutFromGoogle() // Ensures a fresh login
            if (checkGooglePlayServices()) {
                signInWithGoogle()
            } else {
                showToast("Google Play Services not available. Update required.")
            }
        }
    }

    private fun loginUser(email: String, password: String) {
        val request = LoginRequest(email, password)

        RetrofitClient.instance.login(request).enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful) {
                    val loginResponse = response.body()
                    val role = loginResponse?.role

                    if (role == null) {
                        showToast("Login Successful. Role not found.")
                        saveUserData(email, null, loginResponse?.name ?: "Unknown")
                        navigateToHome(null)
                    } else if (role.startsWith("Faculty-")) {
                        val facultyRole = role.substringAfter("Faculty-")
                        showToast("Login Successful as $facultyRole")
                        saveFacultyData(email, facultyRole, loginResponse.name ?: "Unknown")
                        navigateToFacultyHome(facultyRole) // Navigate to Faculty Home
                    } else {
                        showToast("Login Successful as $role")
                        saveUserData(email, role, loginResponse.name ?: "Unknown")
                        navigateToHome(role)
                    }

                } else {
                    showToast("Invalid Credentials")
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                showToast("Error: ${t.message}")
            }
        })
    }

    private fun signInWithGoogle() {
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account: GoogleSignInAccount = task.getResult(ApiException::class.java)!!

                val idToken = account.idToken
                val email = account.email ?: "Unknown Email"
                val displayName = account.displayName ?: "Unknown Name"

                Log.d("GoogleSignIn", "ID Token: $idToken")

                RetrofitClient.instance.googleLogin(mapOf("idToken" to (idToken ?: "")))
                    .enqueue(object : Callback<LoginResponse> {
                        override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                            if (response.isSuccessful) {
                                val loginResponse = response.body()
                                showToast("Signed in as: $displayName")

                                saveUserData(email, "GOOGLE_USER", displayName)
                                navigateToHome("GOOGLE_USER")
                            } else {
                                showToast("Google authentication failed")
                            }
                        }

                        override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                            showToast("Error: ${t.message}")
                        }
                    })

            } catch (e: ApiException) {
                Log.e("GoogleSignIn", "Google Sign-In failed", e)
                showToast("Google Sign-In failed: ${e.statusCode}")
            }
        }
    }

    private fun signOutFromGoogle() {
        googleSignInClient.signOut().addOnCompleteListener {
            Log.d("GoogleSignIn", "Google Sign-Out successful")
        }
    }

    private fun checkGooglePlayServices(): Boolean {
        val googleApiAvailability = GoogleApiAvailability.getInstance()
        val status = googleApiAvailability.isGooglePlayServicesAvailable(this)
        return if (status == ConnectionResult.SUCCESS) {
            true
        } else {
            googleApiAvailability.getErrorDialog(this, status, 9000)?.show()
            false
        }
    }

    private fun saveUserData(email: String, role: String?, name: String) {
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        with(sharedPreferences.edit()) {
            putString("studentEmail", email)
            putString("userRole", role)
            putString("userName", name)
            putString("facultyEmail","")
            putString("facultyRole","")
            apply()
        }
    }

    private fun saveFacultyData(email: String, role: String?, name: String) {
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        with(sharedPreferences.edit()) {
            putString("studentEmail", "")
            putString("userRole", "")
            putString("userName", "")
            putString("facultyEmail",email)
            putString("facultyRole",role)
            apply()
        }
    }

    private fun navigateToHome(role: String?) {
        val intent = Intent(this@LoginActivity, HomeActivity::class.java).apply {
            putExtra("USER_ROLE", role)
        }
        startActivity(intent)
        finish()
    }

    private fun navigateToFacultyHome(role: String?) {
        val intent = Intent(this@LoginActivity, FacultyHomeActivity::class.java).apply { // Navigation change
            putExtra("USER_ROLE", role)
        }
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}