package com.example.studentpermission.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.R
import com.example.studentpermission.ui.models.LeaveRequest

class LeaveApprovalAdapter(
    private val leaveRequests: List<LeaveRequest>,
    private val approveLeave: (LeaveRequest) -> Unit,
    private val rejectLeave: (LeaveRequest) -> Unit
) : RecyclerView.Adapter<LeaveApprovalAdapter.LeaveViewHolder>() {

    class LeaveViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvStudentEmail: TextView = itemView.findViewById(R.id.tvStudentEmail) // ✅ Show student email
        val tvLeaveType: TextView = itemView.findViewById(R.id.tvLeaveType)
        val tvLeaveDate: TextView = itemView.findViewById(R.id.tvLeaveDate)
        val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        val btnApprove: Button = itemView.findViewById(R.id.btnApprove)
        val btnReject: Button = itemView.findViewById(R.id.btnReject)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LeaveViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_leave_request, parent, false)
        return LeaveViewHolder(view)
    }

    override fun onBindViewHolder(holder: LeaveViewHolder, position: Int) {
        val request = leaveRequests[position]
        holder.tvStudentEmail.text = request.studentEmail  // ✅ Show email
        holder.tvLeaveType.text = request.leaveType
        holder.tvLeaveDate.text = request.leaveDate
        holder.tvStatus.text = request.status

        holder.btnApprove.setOnClickListener { approveLeave(request) }
        holder.btnReject.setOnClickListener { rejectLeave(request) }
    }

    override fun getItemCount(): Int = leaveRequests.size
}
