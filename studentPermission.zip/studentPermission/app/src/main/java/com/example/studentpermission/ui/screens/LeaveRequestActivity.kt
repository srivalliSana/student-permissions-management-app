package com.example.studentpermission.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studentpermission.LeaveApiService
import com.example.studentpermission.R
import com.example.studentpermission.ui.models.LeaveRequest
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.Calendar

class LeaveRequestActivity : AppCompatActivity() {

    private lateinit var spLeaveType: Spinner
    private lateinit var etOtherLeaveType: EditText
    private lateinit var tvStartDate: TextView
    private lateinit var tvEndDate: TextView
    private lateinit var tvStartTime: TextView
    private lateinit var tvEndTime: TextView
    private lateinit var btnSelectStartDate: Button
    private lateinit var btnSelectEndDate: Button
    private lateinit var btnSelectStartTime: Button
    private lateinit var btnSelectEndTime: Button
    private lateinit var etReason: EditText
    private lateinit var btnSubmit: Button

    // New approval authority spinners
    private lateinit var spHOD: Spinner
    private lateinit var spMentor: Spinner
    private lateinit var spDeputyRegistrar: Spinner
    private lateinit var spChiefWarden: Spinner
    private lateinit var spHostelSuperintendent: Spinner
    private lateinit var llHostellerApprovals: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leave_request)

        val userRole = intent.getStringExtra("USER_ROLE") ?: "DAY_SCHOLAR"
        val userGender = intent.getStringExtra("USER_GENDER") ?: "MALE"


        initializeViews()
        setupLeaveOptions(userRole)
        setupApprovalAuthorities(userRole, userGender)

        btnSelectStartDate.setOnClickListener { selectDate(tvStartDate) }
        btnSelectEndDate.setOnClickListener { selectDate(tvEndDate) }
        btnSelectStartTime.setOnClickListener { selectTime(tvStartTime) }
        btnSelectEndTime.setOnClickListener { selectTime(tvEndTime) }

        btnSubmit.setOnClickListener { submitLeaveRequest() }
    }

    private fun initializeViews() {
        spLeaveType = findViewById(R.id.spLeaveType)
        etOtherLeaveType = findViewById(R.id.etOtherLeaveType)
        tvStartDate = findViewById(R.id.tvStartDate)
        tvEndDate = findViewById(R.id.tvEndDate)
        tvStartTime = findViewById(R.id.tvStartTime)
        tvEndTime = findViewById(R.id.tvEndTime)
        btnSelectStartDate = findViewById(R.id.btnSelectStartDate)
        btnSelectEndDate = findViewById(R.id.btnSelectEndDate)
        btnSelectStartTime = findViewById(R.id.btnSelectStartTime)
        btnSelectEndTime = findViewById(R.id.btnSelectEndTime)
        etReason = findViewById(R.id.etReason)
        btnSubmit = findViewById(R.id.btnSubmit)

        // Initialize approval authority spinners
        spHOD = findViewById(R.id.spHOD)
        spMentor = findViewById(R.id.spMentor)
        spDeputyRegistrar = findViewById(R.id.spDeputyRegistrar)
        spChiefWarden = findViewById(R.id.spChiefWarden)
        spHostelSuperintendent = findViewById(R.id.spHostelSuperintendent)
        llHostellerApprovals = findViewById(R.id.llHostellerApprovals)
    }

    private fun setupLeaveOptions(role: String) {
        val leaveTypes = if (role == "HOSTELLER") {
            arrayOf("Select Type of Leave", "Outing", "Hosteller Leave", "Other")
        } else {
            arrayOf("Select Type of Leave", "Medical Leave", "Internship Leave", "CSR Leave", "Branding Leave", "Other")
        }

        spLeaveType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, leaveTypes)

        spLeaveType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                adjustFieldsBasedOnLeaveType(spLeaveType.selectedItem.toString())
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupApprovalAuthorities(role: String, gender: String) {
        // Setup HOD dropdown with actual faculty names
        val hodList = arrayOf(
            "Select HOD",
            "Oliver Brown", "Scarlett Harris", "Aiden Young",
            "Maya Hall", "Aria Adams", "Peyton Lewis",
            "Cameron Hill", "Autumn Lopez", "Sofia Carter",
            "Alyssa Campbell", "Nora Perez", "Bella Cooper"
        )
        spHOD.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, hodList)

        // Setup Mentor dropdown with actual faculty names
        val mentorList = arrayOf(
            "Select Mentor",
            "Evelyn Garcia", "Elijah White", "Mila King",
            "Isaac Lee", "Joshua Scott", "Ryan Clark",
            "Madison Walker", "Grayson Robinson", "Landon Green",
            "Theodore Nelson", "Jeremiah Mitchell", "Dominic Rivera"
        )
        spMentor.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, mentorList)

        // Setup Deputy Registrar dropdown with actual faculty names
        val registrarList = arrayOf(
            "Select Deputy Registrar",
            "Henry Wilson", "Lily Jackson"
        )
        spDeputyRegistrar.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, registrarList)

        // Show or hide hosteller-specific approvals
        if (role == "HOSTELLER") {
            llHostellerApprovals.visibility = View.VISIBLE

            // Setup Chief Warden dropdown based on gender
            val wardenList = if (gender == "FEMALE") {
                arrayOf("Select Chief Warden", "Lucas Anderson")
            } else {
                arrayOf("Select Chief Warden", "Zoe Martinez")
            }
            spChiefWarden.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, wardenList)

            // Setup Hostel Superintendent dropdown based on gender
            val superintendentList = if (gender == "FEMALE") {
                arrayOf("Select Hostel Superintendent", "Sebastian Thomas")
            } else {
                arrayOf("Select Hostel Superintendent", "Chloe Taylor")
            }
            spHostelSuperintendent.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, superintendentList)
        } else {
            llHostellerApprovals.visibility = View.GONE
        }
    }

    private fun adjustFieldsBasedOnLeaveType(leaveType: String) {
        hideAllFields()

        when (leaveType) {
            "Select Type of Leave" -> Unit // Keep everything hidden
            "Outing" -> showViews(tvStartTime, btnSelectStartTime)
            "Medical Leave" -> showViews(tvStartDate, btnSelectStartDate)
            "Internship Leave", "CSR Leave", "Branding Leave", "Hosteller Leave" ->
                showViews(tvStartDate, btnSelectStartDate, tvEndDate, btnSelectEndDate)
            "Other" -> {
                etOtherLeaveType.hint = "Enter leave type"
                showViews(etOtherLeaveType, tvStartDate, btnSelectStartDate, tvEndDate, btnSelectEndDate)
            }
        }
    }

    private fun hideAllFields() {
        listOf(
            etOtherLeaveType, tvStartDate, btnSelectStartDate, tvEndDate, btnSelectEndDate,
            tvStartTime, btnSelectStartTime, tvEndTime, btnSelectEndTime
        ).forEach { it.setVisible(false) }
    }

    private fun showViews(vararg views: View) {
        views.forEach { it.setVisible(true) }
    }

    private fun selectDate(textView: TextView) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(
            this, { _, year, month, day ->
                textView.text = "$day/${month + 1}/$year"
            },
            calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun selectTime(textView: TextView) {
        val calendar = Calendar.getInstance()
        TimePickerDialog(
            this, { _, hour, minute ->
                textView.text = String.format("%02d:%02d", hour, minute)
            },
            calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false
        ).show()
    }

    private fun submitLeaveRequest() {
        // Basic validation
        val selectedLeaveType = spLeaveType.selectedItem.toString()
        if (selectedLeaveType == "Select Type of Leave") {
            Toast.makeText(this, "Please select a leave type", Toast.LENGTH_SHORT).show()
            return
        }

        // Validate approval authorities
        if (spHOD.selectedItemPosition == 0 ||
            spMentor.selectedItemPosition == 0 ||
            spDeputyRegistrar.selectedItemPosition == 0) {
            Toast.makeText(this, "Please select all approval authorities", Toast.LENGTH_SHORT).show()
            return
        }

        // Check hosteller approvals if applicable
        if (llHostellerApprovals.visibility == View.VISIBLE &&
            (spChiefWarden.selectedItemPosition == 0 || spHostelSuperintendent.selectedItemPosition == 0)) {
            Toast.makeText(this, "Please select all hostel approval authorities", Toast.LENGTH_SHORT).show()
            return
        }

        // Get shared preferences
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val studentEmail = sharedPreferences.getString("studentEmail", null)

        if (studentEmail.isNullOrEmpty()) {
            Toast.makeText(this, "Error: Student email not found", Toast.LENGTH_SHORT).show()
            return
        }

        // Prepare leave request data
        val otherLeaveType = if (selectedLeaveType == "Other")
            etOtherLeaveType.text.toString().trim()
        else
            null

        // Get approval authorities
        val hodName = spHOD.selectedItem.toString()
        val mentorName = spMentor.selectedItem.toString()
        val registrarName = spDeputyRegistrar.selectedItem.toString()
        val chiefWardenName = if (llHostellerApprovals.visibility == View.VISIBLE)
            spChiefWarden.selectedItem.toString()
        else
            null
        val superintendentName = if (llHostellerApprovals.visibility == View.VISIBLE)
            spHostelSuperintendent.selectedItem.toString()
        else
            null

        val request = LeaveRequest(
            studentEmail = studentEmail,
            leaveType = selectedLeaveType,
            otherLeaveType = otherLeaveType,
            startDate = tvStartDate.text.toString(),
            endDate = tvEndDate.text.toString(), // Will be empty string if not set
            startTime = tvStartTime.text.toString(), // Will be empty string if not set
            endTime = tvEndTime.text.toString(), // Will be empty string if not set
            reason = etReason.text.toString().trim(),
            leaveDate = tvStartDate.text.toString(), // Using start date as leave date
            status = "Pending",
            hodApprover = hodName,
            mentorApprover = mentorName,
            registrarApprover = registrarName,
            chiefWardenApprover = chiefWardenName,
            superintendentApprover = superintendentName
        )

        // Retrofit setup
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:8080/")    // Ensure this matches your backend URL
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val api = retrofit.create(LeaveApiService::class.java)

        // Submit leave request
        api.submitLeaveRequest(request).enqueue(object : Callback<List<LeaveRequest>> {
            override fun onResponse(call: Call<List<LeaveRequest>>, response: Response<List<LeaveRequest>>) {
                if (response.isSuccessful) {
                    Toast.makeText(
                        this@LeaveRequestActivity,
                        "Leave request submitted successfully!",
                        Toast.LENGTH_LONG
                    ).show()
                    setResult(RESULT_OK)
                    finish()
                } else {
                    // Log the error in Logcat
                    try {
                        Log.e("LeaveRequestActivity", "Error: ${response.errorBody()?.string()}")
                    } catch (e: Exception) {
                        Log.e("LeaveRequestActivity", "Error: ${e.message}")
                    }
                    Toast.makeText(
                        this@LeaveRequestActivity,
                        "Failed to submit leave request",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<LeaveRequest>>, t: Throwable) {
                Log.e("LeaveRequestActivity", "Network error", t) // Log the full stack trace
                Toast.makeText(
                    this@LeaveRequestActivity,
                    "Network error: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun View.setVisible(isVisible: Boolean) {
        visibility = if (isVisible) View.VISIBLE else View.GONE
    }
}