package com.example.studentpermission.ui.models

data class LoginRequest(val email: String, val password: String)
