package com.example.studentpermission.ui.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.R
import com.example.studentpermission.ui.models.LeaveRequest

class FacultyLeaveRequestAdapter(
    private val requests: List<LeaveRequest>,
    private val onApprove: (LeaveRequest) -> Unit,
    private val onReject: (LeaveRequest) -> Unit
) : RecyclerView.Adapter<FacultyLeaveRequestAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvStudentName: TextView = itemView.findViewById(R.id.tvStudentName)
        val tvLeaveType: TextView = itemView.findViewById(R.id.tvLeaveType)
        val tvDates: TextView = itemView.findViewById(R.id.tvDates)
        val tvReason: TextView = itemView.findViewById(R.id.tvReason)
        val btnApprove: Button = itemView.findViewById(R.id.btnApprove)
        val btnReject: Button = itemView.findViewById(R.id.btnReject)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.faculty_request_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val request = requests[position]
        holder.tvStudentName.text = "Student: ${request.studentEmail}"
        holder.tvLeaveType.text = "Type: ${request.leaveType}"
        holder.tvDates.text = "Dates: ${request.startDate} - ${request.endDate}"
        holder.tvReason.text = "Reason: ${request.reason}"

        Log.d("FacultyLeaveRequestAdapter", "Binding request: $request") // Added log

        holder.btnApprove.setOnClickListener { onApprove(request) }
        holder.btnReject.setOnClickListener { onReject(request) }
    }

    override fun getItemCount() = requests.size
}