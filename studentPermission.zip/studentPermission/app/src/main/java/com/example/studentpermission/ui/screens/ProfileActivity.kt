package com.example.studentpermission.ui.screens

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.studentpermission.R

class ProfileActivity : AppCompatActivity() {

    private lateinit var ivProfileImage: ImageView
    private lateinit var tvName: TextView
    private lateinit var tvStudentID: TextView
    private lateinit var tvBio: TextView
    private lateinit var btnEditProfile: ImageButton
    private lateinit var btnEditProfileImage: ImageButton
    private lateinit var switchDarkMode: Switch
    private lateinit var btnIncreaseFont: Button
    private lateinit var btnDecreaseFont: Button

    private val PICK_IMAGE_REQUEST = 1
    private var currentFontSize = 16f
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        ivProfileImage = findViewById(R.id.ivProfileImage)
        tvName = findViewById(R.id.tvName)
        tvStudentID = findViewById(R.id.tvStudentID)
        tvBio = findViewById(R.id.tvBio)
        btnEditProfile = findViewById(R.id.btnEditProfile)
        btnEditProfileImage = findViewById(R.id.btnEditProfileImage)
        switchDarkMode = findViewById(R.id.switchDarkMode)
        btnIncreaseFont = findViewById(R.id.btnIncreaseFont)
        btnDecreaseFont = findViewById(R.id.btnDecreaseFont)

        sharedPreferences = getSharedPreferences("Settings", MODE_PRIVATE)

        loadProfileData()

        btnEditProfile.setOnClickListener { showEditProfileDialog() }
        btnEditProfileImage.setOnClickListener { pickImageFromGallery() }

        val isDarkMode = sharedPreferences.getBoolean("DarkMode", false)
        switchDarkMode.isChecked = isDarkMode
        setDarkMode(isDarkMode)

        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            setDarkMode(isChecked)
            sharedPreferences.edit().putBoolean("DarkMode", isChecked).apply()
        }

        btnIncreaseFont.setOnClickListener { adjustFontSize(2f) }
        btnDecreaseFont.setOnClickListener { adjustFontSize(-2f) }
    }

    private fun loadProfileData() {
        tvName.text = "John Doe"
        tvStudentID.text = "CUTM123456"
        tvBio.text = "Computer Science Student at CUTM."
    }

    private fun showEditProfileDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_profile, null)
        val etEditName = dialogView.findViewById<EditText>(R.id.etEditName)
        val etEditBio = dialogView.findViewById<EditText>(R.id.etEditBio)

        etEditName.setText(tvName.text)
        etEditBio.setText(tvBio.text)

        AlertDialog.Builder(this)
            .setTitle("Edit Profile")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                tvName.text = etEditName.text.toString()
                tvBio.text = etEditBio.text.toString()
                Toast.makeText(this, "Profile Updated", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    private fun setDarkMode(enabled: Boolean) {
        AppCompatDelegate.setDefaultNightMode(if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
    }

    private fun adjustFontSize(change: Float) {
        currentFontSize = (currentFontSize + change).coerceIn(12f, 24f)
        tvName.textSize = currentFontSize
        tvStudentID.textSize = currentFontSize - 2
        tvBio.textSize = currentFontSize - 4
    }
}
