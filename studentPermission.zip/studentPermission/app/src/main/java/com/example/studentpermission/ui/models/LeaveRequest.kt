package com.example.studentpermission.ui.models

import android.os.Parcel
import android.os.Parcelable

data class LeaveRequest(
    val studentEmail: String?,
    val leaveType: String?,
    val otherLeaveType: String? = null,
    val startDate: String?,
    val endDate: String? = "",
    val startTime: String? = "",
    val endTime: String? = "",
    val reason: String? = "",
    val leaveDate: String?,
    val status: String?,
    val hodApprover: String? = "",
    val mentorApprover: String? = "",
    val registrarApprover: String? = "",
    val chiefWardenApprover: String? = null,
    val superintendentApprover: String? = null
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(studentEmail)
        parcel.writeString(leaveType)
        parcel.writeString(otherLeaveType)
        parcel.writeString(startDate)
        parcel.writeString(endDate)
        parcel.writeString(startTime)
        parcel.writeString(endTime)
        parcel.writeString(reason)
        parcel.writeString(leaveDate)
        parcel.writeString(status)
        parcel.writeString(hodApprover)
        parcel.writeString(mentorApprover)
        parcel.writeString(registrarApprover)
        parcel.writeString(chiefWardenApprover)
        parcel.writeString(superintendentApprover)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<LeaveRequest> {
        override fun createFromParcel(parcel: Parcel): LeaveRequest? {
            return LeaveRequest(parcel)
        }

        override fun newArray(size: Int): Array<LeaveRequest?> {
            return arrayOfNulls(size)
        }
    }
}