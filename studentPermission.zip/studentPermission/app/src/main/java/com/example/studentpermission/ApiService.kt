package com.example.studentpermission


import com.example.studentpermission.ui.models.LeaveRequest
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import com.example.studentpermission.ui.models.LoginRequest
import com.example.studentpermission.ui.models.LoginResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @POST("api/users/login")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @POST("/api/users/google-login")
    fun googleLogin(@Body request: Map<String, String>): Call<LoginResponse>

    @GET("api/leave/pending")
    fun getPendingRequests(): Call<List<LeaveRequest>>

    @POST("api/leave/approve/{id}")
    fun approveRequest(@Path("id") id: Long): Call<LeaveRequest>

    @POST("api/leave/reject/{id}")
    fun rejectRequest(@Path("id") id: Long): Call<LeaveRequest>

}
