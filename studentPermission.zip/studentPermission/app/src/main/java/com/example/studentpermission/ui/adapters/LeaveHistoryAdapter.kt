package com.example.studentpermission.ui.adapters

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.R
import com.example.studentpermission.ui.models.LeaveRequest
import com.example.studentpermission.ui.LeaveDetailActivity

class LeaveHistoryAdapter(
    private var leaveList: List<LeaveRequest>,
    private val loggedInEmail: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var filteredLeaveList: List<LeaveRequest> = emptyList()

    init {
        updateFilteredLeaveList()
    }

    companion object {
        private const val VIEW_TYPE_LEAVE = 1
        private const val VIEW_TYPE_EMPTY = 2
    }

    override fun getItemViewType(position: Int): Int {
        return if (filteredLeaveList.isEmpty()) VIEW_TYPE_EMPTY else VIEW_TYPE_LEAVE
    }

    class LeaveViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvStudentEmail: TextView = itemView.findViewById(R.id.tvStudentEmail)
        val tvLeaveType: TextView = itemView.findViewById(R.id.tvLeaveType)
        val tvLeaveDate: TextView = itemView.findViewById(R.id.tvLeaveDate)
        val tvLeaveStatus: TextView = itemView.findViewById(R.id.tvLeaveStatus)
    }

    class EmptyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNoHistory: TextView = itemView.findViewById(R.id.tvNoHistory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_LEAVE) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_leave_history, parent, false)
            LeaveViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_no_leave_history, parent, false)
            EmptyViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (filteredLeaveList.isEmpty() && holder is EmptyViewHolder) {
            holder.tvNoHistory.text = "No leave history found"
        } else if (holder is LeaveViewHolder) {
            val leave = filteredLeaveList[position]
            holder.tvStudentEmail.text = leave.studentEmail
            holder.tvLeaveType.text = leave.leaveType
            holder.tvLeaveDate.text = leave.leaveDate
            holder.tvLeaveStatus.text = leave.status

            Log.d("LeaveHistoryAdapter", "Displaying Leave for: ${leave.studentEmail}")

            holder.itemView.setOnClickListener {
                val intent = Intent(holder.itemView.context, LeaveDetailActivity::class.java).apply {
                    putExtra("leaveRequest", leave)
                }
                holder.itemView.context.startActivity(intent)
            }
        }
    }

    override fun getItemCount(): Int {
        return if (filteredLeaveList.isEmpty()) 1 else filteredLeaveList.size
    }

    fun updateLeaveList(newList: List<LeaveRequest>) {
        leaveList = newList
        updateFilteredLeaveList()
        notifyDataSetChanged()
    }

    private fun updateFilteredLeaveList() {
        filteredLeaveList = leaveList.filter { it.studentEmail == loggedInEmail }
    }

}
