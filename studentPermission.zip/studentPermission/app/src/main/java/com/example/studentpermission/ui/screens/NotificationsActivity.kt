package com.example.studentpermission.ui.screens

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.R
import com.example.studentpermission.ui.adapters.NotificationsAdapter

class NotificationsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewNotifications)

        // Sample notification list (replace with real data from API/Database)
        val notificationsList = listOf(
            "Your leave request has been approved.",
            "New notice from administration.",
            "Upcoming holiday announcement."
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = NotificationsAdapter(notificationsList)
    }
}
