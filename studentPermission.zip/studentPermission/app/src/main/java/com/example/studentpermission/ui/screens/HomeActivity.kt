package com.example.studentpermission.ui.screens



import android.content.Intent

import android.os.Bundle

import android.widget.Button

import android.widget.ImageButton

import android.widget.Toast

import androidx.appcompat.app.AppCompatActivity

import com.example.studentpermission.R

import com.example.studentpermission.ui.screens.LeaveRequestActivity

class HomeActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_home)



// Retrieve user role

        val userRole = intent.getStringExtra("USER_ROLE") ?: "DAY_SCHOLAR" // Default to Day Scholar

        showToast("Logged in as: $userRole")



        val btnRequestLeave = findViewById<Button>(R.id.btnRequestLeave)

        val btnLeaveHistory = findViewById<Button>(R.id.btnLeaveHistory)

        val btnProfileIcon = findViewById<ImageButton>(R.id.btnProfileIcon)

        val btnQRScanner = findViewById<ImageButton>(R.id.btnQRScanner)

        val btnNotificationIcon = findViewById<ImageButton>(R.id.btnNotificationIcon)



        btnRequestLeave.setOnClickListener {

            val intent = Intent(this, LeaveRequestActivity::class.java)

            intent.putExtra("USER_ROLE", userRole) // Pass role to Leave Request

            startActivity(intent)

        }



        btnLeaveHistory.setOnClickListener {

            startActivity(Intent(this, LeaveHistoryActivity::class.java))

        }



        btnProfileIcon.setOnClickListener {

            startActivity(Intent(this, ProfileActivity::class.java))

        }



        btnQRScanner.setOnClickListener {

            startActivity(Intent(this, QRCodeScannerActivity::class.java))

        }



        btnNotificationIcon.setOnClickListener {

            startActivity(Intent(this, NotificationsActivity::class.java))

        }

    }



    private fun showToast(message: String) {

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    }

}