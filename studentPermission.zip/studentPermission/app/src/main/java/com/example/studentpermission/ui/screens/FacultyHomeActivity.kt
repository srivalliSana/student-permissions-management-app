package com.example.studentpermission.ui.screens

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.LeaveApiService
import com.example.studentpermission.R
import com.example.studentpermission.ui.adapters.FacultyLeaveRequestAdapter
import com.example.studentpermission.ui.models.LeaveRequest
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class FacultyHomeActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var leaveAdapter: FacultyLeaveRequestAdapter
    private val leaveRequests = mutableListOf<LeaveRequest>()
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var facultyName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_faculty_home)

        supportActionBar?.title = "Faculty Dashboard"
        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        facultyName = sharedPreferences.getString("name", "") ?: ""

        leaveAdapter = FacultyLeaveRequestAdapter(leaveRequests,
            onApprove = { request -> handleApprove(request) },
            onReject = { request -> handleReject(request) }
        )
        recyclerView.adapter = leaveAdapter

        fetchLeaveRequests()
    }

    private fun fetchLeaveRequests() {
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:8080/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val api = retrofit.create(LeaveApiService::class.java)

        Log.d("FacultyHomeActivity", "Fetching requests for faculty: $facultyName") // Added log

        api.getRequestsForFaculty(facultyName).enqueue(object : Callback<List<LeaveRequest>> {
            override fun onResponse(call: Call<List<LeaveRequest>>, response: Response<List<LeaveRequest>>) {
                Log.d("FacultyHomeActivity", "HTTP response code: ${response.code()}")
                Log.d("FacultyHomeActivity", "HTTP response body: ${response.body()}")

                if (response.isSuccessful) {
                    val requests = response.body() ?: emptyList()
                    Log.d("FacultyHomeActivity", "Received ${requests.size} leave requests")

                    leaveRequests.clear()
                    leaveRequests.addAll(requests)

                    // Added logging to inspect the data
                    requests.forEach { request ->
                        Log.d("FacultyHomeActivity", "Request: $request")
                    }

                    runOnUiThread { // Added runOnUiThread
                        leaveAdapter.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(this@FacultyHomeActivity, "Failed to fetch requests", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<LeaveRequest>>, t: Throwable) {
                Log.e("FacultyHomeActivity", "Network error: ${t.message}", t)
                Toast.makeText(this@FacultyHomeActivity, "Network error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun handleApprove(request: LeaveRequest) {
        Log.d("FacultyHomeActivity", "Approve: ${request.studentEmail}")
        Toast.makeText(this, "Approved: ${request.studentEmail}", Toast.LENGTH_SHORT).show()
        // Add your API call to approve the leave request
    }

    private fun handleReject(request: LeaveRequest) {
        Log.d("FacultyHomeActivity", "Reject: ${request.studentEmail}")
        Toast.makeText(this, "Rejected: ${request.studentEmail}", Toast.LENGTH_SHORT).show()
        // Add your API call to reject the leave request
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.faculty_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}