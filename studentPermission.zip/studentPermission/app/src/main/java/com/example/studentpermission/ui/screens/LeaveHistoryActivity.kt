package com.example.studentpermission.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.studentpermission.LeaveApiService
import com.example.studentpermission.R
import com.example.studentpermission.ui.adapters.LeaveHistoryAdapter
import com.example.studentpermission.ui.models.LeaveRequest
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory

class LeaveHistoryActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var leaveHistoryAdapter: LeaveHistoryAdapter

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("http://10.0.2.2:8080/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private val api: LeaveApiService by lazy {
        retrofit.create(LeaveApiService::class.java)
    }

    private val leaveHistoryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val updatedLeaveHistory = result.data?.getParcelableArrayListExtra<LeaveRequest>("updatedLeaveHistory")
            updatedLeaveHistory?.let {
                leaveHistoryAdapter.updateLeaveList(it)
            }
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leave_history)

        recyclerView = findViewById(R.id.rvLeaveHistory)
        recyclerView.layoutManager = LinearLayoutManager(this)

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val email = sharedPreferences.getString("studentEmail", null)

        if (email.isNullOrEmpty()) {
            Toast.makeText(this, "Please log in to continue", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        leaveHistoryAdapter = LeaveHistoryAdapter(emptyList(), email)
        recyclerView.adapter = leaveHistoryAdapter

        fetchLeaveHistory(email)
    }

    override fun onResume() {
        super.onResume()
        val email = sharedPreferences.getString("studentEmail", null)
        email?.let { fetchLeaveHistory(it) }
    }

    private fun fetchLeaveHistory(email: String) {
        Log.d("LeaveHistoryActivity", "Fetching leave history for: $email")

        api.getLeaveHistory(email).enqueue(object : Callback<List<LeaveRequest>> {
            override fun onResponse(call: Call<List<LeaveRequest>>, response: Response<List<LeaveRequest>>) {
                if (response.isSuccessful) {
                    response.body()?.let { leaveList ->
                        leaveHistoryAdapter.updateLeaveList(leaveList)
                    } ?: run {
                        Toast.makeText(this@LeaveHistoryActivity, "No leave history found", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    handleApiError(response)
                }
            }

            override fun onFailure(call: Call<List<LeaveRequest>>, t: Throwable) {
                Toast.makeText(this@LeaveHistoryActivity, "Network error! Check your connection.", Toast.LENGTH_SHORT).show()
                Log.e("LeaveHistoryActivity", "API call failed", t)
            }
        })
    }

    private fun handleApiError(response: Response<List<LeaveRequest>>) {
        when (response.code()) {
            401 -> {
                Toast.makeText(this, "Session expired! Please log in again.", Toast.LENGTH_SHORT).show()
                sharedPreferences.edit().clear().apply()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
            else -> {
                Log.e("LeaveHistoryActivity", "Error code: ${response.code()}, Error body: ${response.errorBody()?.string()}")
                Toast.makeText(this, "Failed to fetch leave history", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
