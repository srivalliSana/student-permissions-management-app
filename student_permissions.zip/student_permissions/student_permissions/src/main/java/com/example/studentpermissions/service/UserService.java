package com.example.studentpermissions.service;

import com.example.studentpermissions.model.HostelStudent;
import com.example.studentpermissions.model.Faculty;
import com.example.studentpermissions.repository.HostelStudentRepository;
import com.example.studentpermissions.repository.FacultyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    @Autowired
    private HostelStudentRepository hostelStudentRepository;

    @Autowired
    private FacultyRepository facultyRepository;

    public Map<String, Object> authenticateUser(String email, String password) {
        Map<String, Object> response = new HashMap<>();

        // Check if email exists in hostel_students
        Optional<HostelStudent> hostelStudent = hostelStudentRepository.findByEmail(email);
        if (hostelStudent.isPresent()) {
            if (hostelStudent.get().getPassword().equals(password)) {
                response.put("message", "Login Successful");
                response.put("role", "HOSTELLER");
                response.put("name", hostelStudent.get().getName());
                return response;
            } else {
                response.put("message", "Invalid Password");
                return response;
            }
        }

        // Check if email exists in faculty_list
        Optional<Faculty> faculty = facultyRepository.findByEmail(email);
        if (faculty.isPresent()) {
            if (faculty.get().getPassword().equals(password)) {
                response.put("message", "Login Successful");
                response.put("role", "FACULTY");
                response.put("name", faculty.get().getName());
                return response;
            } else {
                response.put("message", "Invalid Password");
                return response;
            }
        }

        // If email does not exist but matches student email format
        if (email.matches("\\d{12}@cutmap\\.ac\\.in")) {  // Example: 221801234567@cutmap.ac.in
            if (password.equals("123456789a")) {  // Default password for day scholars
                response.put("message", "Login Successful");
                response.put("role", "DAY_SCHOLAR");
                response.put("name", "Unknown Student");
                return response;
            } else {
                response.put("message", "Invalid Password");
                return response;
            }
        }

        // User does not belong to the university
        response.put("message", "This email does not belong to Centurion University.");
        return response;
    }
}
