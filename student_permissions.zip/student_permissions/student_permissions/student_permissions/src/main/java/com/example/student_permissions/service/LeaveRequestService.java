package com.example.student_permissions.service;

import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.repository.LeaveRequestRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaveRequestService {

    private final LeaveRequestRepository leaveRequestRepository;

    public LeaveRequestService(LeaveRequestRepository leaveRequestRepository) {
        this.leaveRequestRepository = leaveRequestRepository;
    }

    // ✅ Save leave request (Ensures email is set)
    public List<LeaveRequest> submitLeaveRequest(LeaveRequest leaveRequest) {
        if (leaveRequest.getStudentEmail() == null || leaveRequest.getStudentEmail().isEmpty()) {
            throw new IllegalArgumentException("Student email is required");
        }
        leaveRequest.setStatus("Pending"); // Default status
        leaveRequestRepository.save(leaveRequest);

        // ✅ Return updated leave history for the student
        return leaveRequestRepository.findByStudentEmail(leaveRequest.getStudentEmail());
    }


    // ✅ Fetch leave history for a student
    public List<LeaveRequest> getLeaveHistory(String studentEmail) {
        return leaveRequestRepository.findByStudentEmail(studentEmail);
    }

    // ✅ Fetch all pending leave requests
    public List<LeaveRequest> getPendingLeaveRequests() {
        return leaveRequestRepository.findByStatus("Pending");
    }

    // ✅ Update leave status (Approve/Reject)
    public LeaveRequest updateLeaveStatus(Long requestId, String status) {
        LeaveRequest leaveRequest = leaveRequestRepository.findById(requestId)
                .orElseThrow(() -> new RuntimeException("Leave request not found"));
        leaveRequest.setStatus(status);
        return leaveRequestRepository.save(leaveRequest);
    }
}