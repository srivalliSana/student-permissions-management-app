package com.example.student_permissions.service;

import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.repository.LeaveRequestRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaveRequestService {

    private final LeaveRequestRepository leaveRequestRepository;

    public LeaveRequestService(LeaveRequestRepository leaveRequestRepository) {
        this.leaveRequestRepository = leaveRequestRepository;
    }

    // Save leave request
    public LeaveRequest submitLeaveRequest(LeaveRequest leaveRequest) {
        leaveRequest.setStatus("Pending"); // Default status
        return leaveRequestRepository.save(leaveRequest);
    }

    // Get leave history of a student
    public List<LeaveRequest> getLeaveHistory(String studentEmail) {
        return leaveRequestRepository.findByStudentEmail(studentEmail);
    }

    // Get all pending leave requests
    public List<LeaveRequest> getPendingLeaveRequests() {
        return leaveRequestRepository.findByStatus("Pending");
    }

    // Update leave status (Approve/Reject)
    public LeaveRequest updateLeaveStatus(Long requestId, String status) {
        LeaveRequest leaveRequest = leaveRequestRepository.findById(requestId)
                .orElseThrow(() -> new RuntimeException("Leave request not found"));

        leaveRequest.setStatus(status);
        return leaveRequestRepository.save(leaveRequest);
    }
}
