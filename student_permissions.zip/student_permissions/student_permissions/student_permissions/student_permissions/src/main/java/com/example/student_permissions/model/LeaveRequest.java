package com.example.student_permissions.model;

import jakarta.persistence.*;

@Entity
@Table(name = "leave_requests")
public class LeaveRequest {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String studentEmail;
    private String leaveType;
    private String otherLeaveType;
    private String startDate;
    private String endDate;
    private String startTime;
    private String endTime;
    private String reason;
    private String leaveDate;
    private String status; // "Pending", "Approved", "Rejected"

    // Constructors
    public LeaveRequest() {}

    public LeaveRequest(String studentEmail, String leaveType, String otherLeaveType, String startDate,
                        String endDate, String startTime, String endTime, String reason, String leaveDate, String status) {
        this.studentEmail = studentEmail;
        this.leaveType = leaveType;
        this.otherLeaveType = otherLeaveType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.reason = reason;
        this.leaveDate = leaveDate;
        this.status = status;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getStudentEmail() { return studentEmail; }
    public void setStudentEmail(String studentEmail) { this.studentEmail = studentEmail; }

    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }

    public String getOtherLeaveType() { return otherLeaveType; }
    public void setOtherLeaveType(String otherLeaveType) { this.otherLeaveType = otherLeaveType; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getLeaveDate() { return leaveDate; }
    public void setLeaveDate(String leaveDate) { this.leaveDate = leaveDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
