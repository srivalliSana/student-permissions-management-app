package com.example.student_permissions.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.student_permissions.model.Faculty;

import java.util.Optional;

public interface FacultyRepository extends JpaRepository<Faculty, Long> {
    Optional<Faculty> findByEmail(String email);
}
