package com.example.student_permissions.repository;

import com.example.student_permissions.model.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {
    List<LeaveRequest> findByStudentEmail(String studentEmail);
    List<LeaveRequest> findByStatus(String status);
}
