package com.example.student_permissions.controller;

import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.service.LeaveRequestService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/leave")
@CrossOrigin(origins = "*") // Allow requests from any frontend
public class LeaveRequestController {

    private final LeaveRequestService leaveRequestService;

    public LeaveRequestController(LeaveRequestService leaveRequestService) {
        this.leaveRequestService = leaveRequestService;
    }

    // ✅ Submit Leave Request
    @PostMapping("/submit")
    public LeaveRequest submitLeaveRequest(@RequestBody LeaveRequest leaveRequest) {
        return leaveRequestService.submitLeaveRequest(leaveRequest);
    }

    // ✅ Get Leave History for a Student
    @GetMapping("/history/{email}")
    public List<LeaveRequest> getLeaveHistory(@PathVariable String email) {
        return leaveRequestService.getLeaveHistory(email);
    }

    // ✅ Get Pending Leave Requests
    @GetMapping("/pending")
    public List<LeaveRequest> getPendingLeaveRequests() {
        return leaveRequestService.getPendingLeaveRequests();
    }

    // ✅ Approve/Reject Leave Request
    @PutMapping("/update-status/{id}/{status}")
    public LeaveRequest updateLeaveStatus(@PathVariable Long id, @PathVariable String status) {
        return leaveRequestService.updateLeaveStatus(id, status);
    }
}
