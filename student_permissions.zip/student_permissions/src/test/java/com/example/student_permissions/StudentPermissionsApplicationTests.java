package com.example.student_permissions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@Import(TestcontainersConfiguration.class)
@SpringBootTest
public class StudentPermissionsApplicationTests {
    @Test
    void contextLoads() {
    }
}
