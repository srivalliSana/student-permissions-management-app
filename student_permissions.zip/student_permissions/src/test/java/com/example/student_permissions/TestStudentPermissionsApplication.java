package com.example.student_permissions;

import org.springframework.boot.SpringApplication;

public class TestStudentPermissionsApplication {

	public static void main(String[] args) {
		SpringApplication.from(StudentPermissionsApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
