package com.example.student_permissions.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.repository.LeaveRequestRepository;
import com.example.student_permissions.service.LeaveHistoryService;

import java.util.List;

@RestController
@RequestMapping("/api/leavehistory")
@CrossOrigin(origins = "*")  // Allow frontend requests
public class LeaveHistoryController {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;
    
    @Autowired
    private LeaveHistoryService leaveHistoryService;

    // ✅ API to fetch leave history for a specific student
    @GetMapping("/{email}")
    public ResponseEntity<?> getUserLeaveHistory(@PathVariable String email) {
        List<LeaveRequest> requests = leaveHistoryService.getLeaveHistory(email);

        if (requests.isEmpty()) {
            return ResponseEntity.ok("No leave history found."); // ✅ Show empty message
        }

        return ResponseEntity.ok(requests);
    }

    // ✅ API to fetch all leave history (for admins)
    @GetMapping("/all")
    public ResponseEntity<List<LeaveRequest>> getAllLeaveHistory() {
        List<LeaveRequest> requests = leaveHistoryService.getAllLeaveHistory();
        return ResponseEntity.ok(requests);
    }

    // ✅ API to fetch leave history for a student (Handles No Requests Case)
    @GetMapping("/leave-history")
    public ResponseEntity<?> getLeaveHistoryH(@RequestParam String email) {
        List<LeaveRequest> leaveRequests = leaveRequestRepository.findByStudentEmail(email);

        if (leaveRequests.isEmpty()) {
            return ResponseEntity.ok("No leave history found."); // ✅ Show message if empty
        }

        return ResponseEntity.ok(leaveRequests);
    }
}
