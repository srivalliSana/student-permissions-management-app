
package com.example.student_permissions.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.repository.LeaveRequestRepository;

@Service
public class LeaveHistoryService {

    private final LeaveRequestRepository leaveRequestRepository;

    public LeaveHistoryService(LeaveRequestRepository leaveRequestRepository) {
        this.leaveRequestRepository = leaveRequestRepository;
    }

    // ✅ Fetch leave history for a student
    public List<LeaveRequest> getLeaveHistory(String studentEmail) {
        return leaveRequestRepository.findByStudentEmail(studentEmail);
    }

    // ✅ Fetch all leave history (for admin use)
    public List<LeaveRequest> getAllLeaveHistory() {
        return leaveRequestRepository.findAll();
    }
}