package com.example.student_permissions.controller;

import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:8080")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/faculty/requests") // New endpoint
    public ResponseEntity<List<LeaveRequest>> getFacultyRequests(@RequestParam("facultyName") String facultyName) {
        List<LeaveRequest> requests = userService.getLeaveRequestsForFaculty(facultyName);
        return ResponseEntity.ok(requests);
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> requestBody) {
        String email = requestBody.get("email");
        String password = requestBody.get("password");
        Map<String, Object> response = userService.authenticateUser(email, password);

        if ("Login Successful".equals(response.get("message"))) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body(response);
        }
    }

    @PostMapping("/google-login")
    public ResponseEntity<Map<String, Object>> googleLogin(@RequestBody Map<String, String> requestBody) {
        String idToken = requestBody.get("idToken");
        Map<String, Object> response = userService.authenticateWithGoogle(idToken);

        if ("Login Successful".equals(response.get("message"))) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body(response);
        }
    }
}