package com.example.student_permissions.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.student_permissions.model.HostelStudent;
import com.example.student_permissions.model.Faculty;
import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.repository.FacultyRepository;
import com.example.student_permissions.repository.HostelStudentRepository;
import com.example.student_permissions.repository.LeaveRequestRepository;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;

@Service
public class UserService {

    @Autowired
    private HostelStudentRepository hostelStudentRepository;

    @Autowired
    private FacultyRepository facultyRepository;

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    private static final String GOOGLE_CLIENT_ID = "747251933695-qa28v2j0jc9o2kldq20vfakd3b453nfq.apps.googleusercontent.com";

    public Map<String, Object> authenticateUser(String email, String password) {
        Map<String, Object> response = new HashMap<>();

        // Check if email exists in hostel_students
        Optional<HostelStudent> hostelStudent = hostelStudentRepository.findByEmail(email);
        if (hostelStudent.isPresent()) {
            if (hostelStudent.get().getPassword().equals(password)) {
                response.put("message", "Login Successful");
                response.put("role", "HOSTELLER");
                response.put("name", hostelStudent.get().getName());
                return response;
            } else {
                response.put("message", "Invalid Password");
                return response;
            }
        }

        // Check if email exists in faculty_list
        Optional<Faculty> faculty = facultyRepository.findByEmail(email);
        if (faculty.isPresent()) {
            if (faculty.get().getPassword().equals(password)) {
                response.put("message", "Login Successful");
                response.put("role", "Faculty-" + faculty.get().getRole()); // Add "Faculty-" prefix
                response.put("name", faculty.get().getName());
                return response;
            } else {
                response.put("message", "Invalid Password");
                return response;
            }
        }

        // If email follows the student pattern
        if (email.matches("\\d{12}@cutmap\\.ac\\.in")) {
            if (password.equals("123456789a")) {
                response.put("message", "Login Successful");
                response.put("role", "DAY_SCHOLAR");
                response.put("name", "Unknown Student");
                return response;
            } else {
                response.put("message", "Invalid Password");
                return response;
            }
        }

        response.put("message", "This email does not belong to Centurion University.");
        return response;
    }

    // Validate Google ID Token
    public Map<String, Object> authenticateWithGoogle(String idToken) {
        Map<String, Object> response = new HashMap<>();

        try {
            @SuppressWarnings("deprecation")
            GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
                    new NetHttpTransport(), JacksonFactory.getDefaultInstance())
                    .setAudience(Collections.singletonList(GOOGLE_CLIENT_ID))
                    .build();

            GoogleIdToken googleIdToken = verifier.verify(idToken);
            if (googleIdToken != null) {
                GoogleIdToken.Payload payload = googleIdToken.getPayload();
                String email = payload.getEmail();
                String name = (String) payload.get("name");

                // Check if email exists in faculty_list
                Optional<Faculty> faculty = facultyRepository.findByEmail(email);
                if (faculty.isPresent()) {
                    response.put("message", "Login Successful");
                    response.put("role", "Faculty-" + faculty.get().getRole()); // Add "Faculty-" prefix
                    response.put("name", faculty.get().getName());
                    response.put("email", email);
                    return response;
                }

                response.put("message", "Login Successful");
                response.put("role", "GOOGLE_USER");
                response.put("name", name);
                response.put("email", email);

                return response;
            } else {
                response.put("message", "Invalid Google ID Token");
                return response;
            }
        } catch (Exception e) {
            response.put("message", "Google authentication failed: " + e.getMessage());
            return response;
        }
    }

    // New method to fetch leave requests for a faculty member
    public List<LeaveRequest> getLeaveRequestsForFaculty(String facultyName) {
        return leaveRequestRepository.findByFacultyName(facultyName);
    }
}