package com.example.student_permissions.controller;

import com.example.student_permissions.model.LeaveRequest;
import com.example.student_permissions.service.LeaveRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/leave")
@CrossOrigin(origins = "*") // Allow frontend requests
public class LeaveRequestController {

    private final LeaveRequestService leaveRequestService;

    @Autowired
    public LeaveRequestController(LeaveRequestService leaveRequestService) {
        this.leaveRequestService = leaveRequestService;
    }

    // ✅ Submit Leave Request
    @PostMapping("/submit")
    public ResponseEntity<List<LeaveRequest>> submitLeaveRequest(@RequestBody LeaveRequest leaveRequest) {
        List<LeaveRequest> updatedLeaveHistory = leaveRequestService.submitLeaveRequest(leaveRequest);
        return ResponseEntity.ok(updatedLeaveHistory);
    }

    // ✅ Get Leave History for a Student
    @GetMapping("/history/{email}")
    public ResponseEntity<List<LeaveRequest>> getLeaveHistory(@PathVariable String email) {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveHistory(email);
        return ResponseEntity.ok(leaveRequests);
    }

    // ✅ Get Pending Leave Requests
    @GetMapping("/pending")
    public ResponseEntity<List<LeaveRequest>> getPendingLeaveRequests() {
        List<LeaveRequest> pendingRequests = leaveRequestService.getPendingLeaveRequests();
        return ResponseEntity.ok(pendingRequests);
    }

    // ✅ Approve/Reject Leave Request
    @PutMapping("/update-status/{id}/{status}")
    public ResponseEntity<LeaveRequest> updateLeaveStatus(@PathVariable Long id, @PathVariable String status) {
        LeaveRequest updatedRequest = leaveRequestService.updateLeaveStatus(id, status);

        if (updatedRequest == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(updatedRequest);
    }
}
