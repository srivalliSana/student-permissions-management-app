package com.example.student_permissions.repository;

import com.example.student_permissions.model.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {

    // ✅ Fetch leave requests based on student email
    @Query("SELECT l FROM LeaveRequest l WHERE l.studentEmail = :email")
    List<LeaveRequest> findByStudentEmail(@Param("email") String email);

    // ✅ Fetch leave requests based on status
    List<LeaveRequest> findByStatus(String status);

    // ✅ Fetch leave requests for a faculty member
    @Query("SELECT l FROM LeaveRequest l WHERE l.hodApprover = :facultyName OR l.mentorApprover = :facultyName OR l.registrarApprover = :facultyName OR l.chiefWardenApprover = :facultyName OR l.superintendentApprover = :facultyName")
    List<LeaveRequest> findByFacultyName(@Param("facultyName") String facultyName);
}