package com.example.student_permissions.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.student_permissions.model.HostelStudent;

import java.util.Optional;

public interface HostelStudentRepository extends JpaRepository<HostelStudent, Long> {
    Optional<HostelStudent> findByEmail(String email);
}