package com.example.student_permissions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentPermissionsApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentPermissionsApplication.class, args);
    }
}
